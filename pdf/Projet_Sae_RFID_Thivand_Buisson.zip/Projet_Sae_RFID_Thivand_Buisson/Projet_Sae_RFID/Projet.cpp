#include "Projet.h"

extern RFID RFID;//initialise le RFID

int badgesValide(void){
  int l_etat = 0;
  if(RFID.isCard() == 1){//vérifie si il y a un badge
  if(RFID.readCardSerial() == 1){//vérifie si le badge est correctement lus 
    for(int ibcl = 0; ibcl<TAILLE;ibcl++){// vérifie si le badge est connue 
      if(g_tab[ibcl].m_octect1 == RFID.serNum[0] && g_tab[ibcl].m_octect2 == RFID.serNum[1] && g_tab[ibcl].m_octect3 == RFID.serNum[2] && g_tab[ibcl].m_octect4 == RFID.serNum[3] && g_tab[ibcl].m_octect5 == RFID.serNum[4] && g_tab[ibcl].m_autorisee){
       Serial.println("bon badge");
        l_etat = 1;// si le badges est connue et correctement lus mettre l_etat a 1
      }
    }

  }
  else{

    Serial.println("mauvais badge");
    l_etat = 0;// si le badge est inconnue
  }
  return l_etat;//retoune l_etat
  }
  else{
    l_etat = 2;
    return l_etat;
  }
 
}

void init_graphe(void){
  g_etat = ATTENTE; //état initial
}

void lire_entrees(TEntrees* xp_entrees){
  xp_entrees->m_t_3s = TempoEstEcoulee();//met m_t_3s a la valeur de la fonction TempoEstEcoulee
  xp_entrees->m_badgeValide = badgesValide();//met m_badgeValide a la valeur de la fonction badgesValide

}

void etat_suivant(TEtat *xp_etat,TEntrees *xp_entrees){//fais les changement d'état selon les entrées et l'état précédent 
  switch(*xp_etat){
    case ATTENTE://si on est dans l'état attente et que on a badgeValide alors on passe a l'état autorisée sinon aller dans l'état non Autorisée
    if(xp_entrees->m_badgeValide == 1){
      *xp_etat = AUTORISEE;
    }
    else if(xp_entrees->m_badgeValide == 0){
      *xp_etat = NAUTORISEE;}
    break;
    case AUTORISEE:*xp_etat = COMPTEUR2;break;// si on est dans l'état Autorisée passer directement dans l'état Compteur2
    case NAUTORISEE:*xp_etat = COMPTEUR1;break;// si on est dans l'état Non Autorisée passer directement dans l'état Compteur1
    case COMPTEUR1://si on est dans l'état compteur 1 et que l'attente de 3s est fini aller dans attente
    if(xp_entrees->m_t_3s == 1){
      *xp_etat = ATTENTE;
    }break;
    case COMPTEUR2://si on est dans l'état compteur 2 et que l'attente de 3s est fini aller dans attente
    if(xp_entrees->m_t_3s == 1){
      *xp_etat = ATTENTE;
    }break;
  }
}

void piloter_sorties(TEtat x_etat) {
  switch(x_etat){
    case ATTENTE://si on est dans l'état Attente faire 
      PORTD = (PORTD & ~MSK_BIT3);// éteint la led rouge
      PORTD = (PORTD & ~MSK_BIT4);// éteint la led verte
      PORTD = (PORTD & ~MSK_BIT8);// éteint le relay     
  break;
  case AUTORISEE://si on est dans l'état Autorisee faire
      PORTD = (PORTD|MSK_BIT4);// allume la led verte
      PORTD = (PORTD|MSK_BIT8);// allume le relay 
      Serial.println("Autorisee");

      /*manque buzzer son aigu*/
      DemarrerTempo(3000);
  break;
  case NAUTORISEE://si on est dans l'état non autorisee faire 
      PORTD = (PORTD & ~MSK_BIT8);// éteint le relay  
      PORTD = (PORTD|MSK_BIT3);// allume la led rouge 
      PORTD = (PORTD & ~MSK_BIT4);// éteint la led verte
      Serial.println("NON Autorisee"); 

      /*manque buzzer son grave*/
      DemarrerTempo(3000);
  break;
  case COMPTEUR1://si on est dans l'état compteur1 faire 
     Serial.println("TEMPO1"); 
     CLKPR = 0b00000000;//initialise le timer en mode normal
     TCCR1B = 0b00000001;//lance le compteur
     TCCR1A = TCCR1A &~ 0b00000011;// met le timer en mode normal
     TCCR1B = TCCR1B &~ 0b00011000;//met le timer en mode normal
     TCNT1 = 33537;//initialise le timer pour les grave 
     bool l_val;
     if(l_val = (TIFR1 & MSK_BIT1)==MSK_BIT1){//Vérifie si le drapeau est levée
     TCNT1 = 33537;//initialise le timer pour les grave 
     TIFR1 = TIFR1|MSK_BIT1;//pour remettre le drapeau a 0
     PORTD = PORTD ^ MSK_BIT7;//inverse l'état du bit 7
     } 

  break;
  case COMPTEUR2://si on est dans l'état compteur2 faire  
     Serial.println("TEMPO2");
     CLKPR = 0b00000000;//initialise le timer en mode normal
     TCCR1B = 0b00000001;//lance le compteur 
     TCCR1A = TCCR1A &~ 0b00000011;//met le timer en mode normal
     TCCR1B = TCCR1B &~ 0b00011000;//met le timer en mode normal
     TCNT1 = 57537;// initialise le timer pour les aigu
     if(l_val = (TIFR1 & MSK_BIT1)==MSK_BIT1){//Vérifie si le drapeau est levée
     TCNT1 = 57537;//initialise le timer pour les grave 
     TIFR1 = TIFR1|MSK_BIT1;//pour remettre le drapeau a 0
     PORTD = PORTD ^ MSK_BIT7;//inverse l'état du bit 7
     } 

  break;
  default:break;
  }
}

/**
 * @brief Fonction auxiliaire pour la temporisation non bloquante.
 * Permet d’éviter une variable globale, grâce à des variables statiques.
 *
 * @param x_sauvegarder Mettre à true pour sauvegarder x_debut et x_duree_ms,
 * à false pour récupérer dans x_debut et x_duree_ms les valeurs sauvegardées
 * @param x_debut Instant où la temporisation a été lancée (valeur de millis())
 * @param x_duree_ms Durée souhaitée de la temporisation
 */
void MemoTempo(bool x_sauvegarder, uint32_t *x_debut, uint32_t *x_duree_ms) {
    static uint32_t s_debut_memo = 0;
    static uint32_t s_duree_memo = 0;
    if (x_sauvegarder) {
        // Mémorisation de l’heure de début et de la durée souhaitée
        // dans les variables statiques
        s_debut_memo = *x_debut;
        s_duree_memo = *x_duree_ms;
    } 
    else {
        // Écriture des variables statiques vers les paramètres de sortie
        *x_debut = s_debut_memo;
        *x_duree_ms = s_duree_memo;
    }	
}

void DemarrerTempo(uint32_t x_duree_ms) {
    uint32_t l_debut = millis();
    // Mémorisation des paramètres pour plus tard
    MemoTempo(true, &l_debut, &x_duree_ms);
}

bool TempoEstEcoulee(void) {
    bool l_ecoulee;
    uint32_t l_debut;
    uint32_t x_duree_ms;
    // Récupération des paramètres de la tempo lancée plus tôt
    MemoTempo(false, &l_debut, &x_duree_ms);

    l_ecoulee = (millis() - l_debut) >= x_duree_ms;
    return l_ecoulee;
}
