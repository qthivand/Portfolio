#pragma once
#include <arduino.h>
#include "RFID.h"
#include <SPI.h>

#define TAILLE 3
#define MSK_BIT1 0b00000001
#define MSK_BIT2 0b00000010
#define MSK_BIT3 0b00000100
#define MSK_BIT4 0b00001000
#define MSK_BIT5 0b00010000
#define MSK_BIT6 0b00100000
#define MSK_BIT7 0b01000000
#define MSK_BIT8 0b10000000



typedef enum{ATTENTE,AUTORISEE,COMPTEUR2,NAUTORISEE,COMPTEUR1,PARAMETRE,CONNUE,INCONNUE}TEtat;//initialise les état du graphe

typedef struct {
  int m_badgeValide;
  bool m_t_3s;
}TEntrees;//initialise les variables des entrées 

typedef struct{
  bool m_autorisee;
  uint8_t m_octect1;
  uint8_t m_octect2;
  uint8_t m_octect3;
  uint8_t m_octect4;
  uint8_t m_octect5;
}TBadgeConnue;// initialise les variable des badges connue 

extern TEtat g_etat;//initialise le typedef enum
extern TEntrees g_entrees;// initialise le type def struct TENTREES
extern TBadgeConnue g_tab[TAILLE]; // initialise le type def struct TBADGECONNUE 

//Fonction badgesValide
//Description : retourne 1 si le badges est connue et correctement lus 
//Paramètre d'entrée : void
//Valeur de retour : int
int badgesValide(void);

//Fonction init_graphe
//Description : initialise le graphe d'état  
//Paramètre d'entrée : void
//Valeur de retour : void
void init_graphe(void);

//Fonction lire_entrees
//Description : lis les entrées de la carte 
//Paramètre d'entrée : TEntrees* xp_entrees
//Valeur de retour : void
void lire_entrees(TEntrees* xp_entrees);

//Fonction etat_suivant
//Description : change d'état le graphe
//Paramètre d'entrée : TEntrees* xp_entrees TEtat *xp_etat
//Valeur de retour : void
void etat_suivant(TEtat *xp_etat,TEntrees *xp_entrees);

//Fonction piloter_sorties
//Description : change d'état les sorties en fonction du graphe d'état 
//Paramètre d'entrée :TEtat x_etat
//Valeur de retour : void
void piloter_sorties(TEtat x_etat);

/**
 * @brief Démarre une temporisation non bloquante.
 * Basée sur la fonction millis(), donc utilise le TIMER0.
 * 
 * @param x_duree_ms Durée de la temporisation en millisecondes
 */
void DemarrerTempo(uint32_t x_duree_ms);

/**
 * @brief Test de la fin de la temporisation démarrée par DemarrerTempo.
 * Précision de 1 ms.
 * 
 * @return true si la temporisation est ecoulée, false sinon.
 */
bool TempoEstEcoulee(void);
